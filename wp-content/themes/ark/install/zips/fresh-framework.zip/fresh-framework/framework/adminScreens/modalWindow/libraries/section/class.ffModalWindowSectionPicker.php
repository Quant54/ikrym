<?php

class ffModalWindowSectionPicker extends ffModalWindow {
	protected function _initialize() {
		$this->_setMenuName('Add Section');
	}
}