<?php

class ffModalWindowLibraryColorEditor extends ffModalWindow {
	protected function _initialize() {
		$this->_setMenuName('Set Visibility');
	}
}